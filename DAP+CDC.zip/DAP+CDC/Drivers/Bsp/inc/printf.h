#ifndef __PRINTF
#define __PRINTF
#include "stm32f1xx_hal.h"

#define PRINTF_UART      USART1



#endif

