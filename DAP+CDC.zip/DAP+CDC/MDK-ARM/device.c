#include "stm32f1xx_hal.h"
#include "usbd_customhid.h"
#include "usb_device.h"
#include "cmsis_os2.h"
#include "rl_usb.h"
#include <stdbool.h>
#include "usbd_composite.h"

static volatile int osFlags;  /* Use "volatile" to prevent GCC optimizing the code. */

void osKernelInitialize(void)
{
  osFlags = 0;
  return;
}

int USBD_Configured(int n)
{
  (void)n;
  HAL_Delay(200);
  LED_connect_GPIO_Port->ODR ^= LED_connect_Pin;
  return (hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED ? 1:0);
}

void USBD_Initialize(int n)
{
  (void)n;

  /**
    * I inserted the call of USBD_HID0_Initialize/USBD_HID0_Uninitialize
    * into usbd_custom_hid_if.c. Please refer:
    *
    * line 179  @ usbd_custom_hid_if.c
    * line 191  @ usbd_custom_hid_if.c
    */
  /* USBD_HID0_Initialize(); */
  return;
}

void USBD_Connect(int n)
{
  (void)n;

  return;
}


osThreadId_t osThreadNew(void (*func)(void *), void * n, void * ctx)
{
  (void)n;

  (*func)(ctx);
  return 0;
}



void osThreadFlagsSet(int tid, int f)
{
  (void)tid;

  osFlags |= f;
  return;
}

int osThreadFlagsWait(int mask, int b, int c)
{
  (void)b;
	(void)c;

  int ret;

  while((osFlags&mask) == 0)
  {
//			CDC_Transmit_FS("yes\r\n",5);
//			HAL_Delay(100);
  }
  ret = osFlags; osFlags &= ~mask;
  return ret;
}


void USBD_HID_GetReportTrigger(int a, int b, void * report, int len)
{
  (void)a;
  (void)b;

  if (USBD_OK != USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, report, len))
  {
    ;
  }
  return;
}


bool USBD_HID0_SetReport (uint8_t rtype, uint8_t req, uint8_t rid, const uint8_t *buf, int32_t len);
 
void USBD_OutEvent(void)
{
  USBD_CUSTOM_HID_HandleTypeDef *hhid = (USBD_CUSTOM_HID_HandleTypeDef *)pHIDData;

  USBD_HID0_SetReport(HID_REPORT_OUTPUT, 0, 0, hhid->Report_buf, USBD_CUSTOMHID_OUTREPORT_BUF_SIZE);
}
 
int32_t USBD_HID0_GetReport (uint8_t rtype, uint8_t req, uint8_t rid, uint8_t *buf);
 
void USBD_InEvent(void)
{
  int32_t len;
 
  USBD_CUSTOM_HID_HandleTypeDef *hhid = (USBD_CUSTOM_HID_HandleTypeDef *)pHIDData;
  if ((len=USBD_HID0_GetReport(HID_REPORT_INPUT, USBD_HID_REQ_EP_INT, 0, hhid->Report_buf)) > 0)
  {
    USBD_HID_GetReportTrigger(0, 0, hhid->Report_buf, len);
  }
}


